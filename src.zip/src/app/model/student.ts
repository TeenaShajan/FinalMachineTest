export class Student {

    studentId:number=0;
    studentName:string="";
}
