export class User {
    userId: number = 0;
    userName: string = '';
    password: string = '';
    //role:Role;
    roleId: number = 0;
    isActive: boolean = false;

}
