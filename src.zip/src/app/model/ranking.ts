export class Ranking {
    applicationCode:number=0;
	studentId:number=0;
    studentName:string;
	courseName:string="";
		average :number=0;
		credits:number=0;
		ranks:number=0;
		approvedDate :Date=new Date();
}
