export class Role {
}
